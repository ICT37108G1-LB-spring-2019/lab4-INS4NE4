export interface IStudent {
  id?: number;
  firstName: string;
  lastName: string;
  perNO: string | number;
}
